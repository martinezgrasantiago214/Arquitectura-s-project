var index =
[
    [ "Descripción General", "index.html#descripcion", null ],
    [ "Funcionalidades Principales", "index.html#funcionalidades", null ],
    [ "Hardware Requerido", "index.html#hardware", null ],
    [ "Estructura del Código", "index.html#estructura", null ],
    [ "Autores", "index.html#autores", null ]
];