var searchData=
[
  ['funcionalidades_20principales_0',['Funcionalidades Principales',['../index.html#funcionalidades',1,'']]]
];
