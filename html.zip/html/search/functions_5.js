var searchData=
[
  ['parpadeoalarma_0',['parpadeoAlarma',['../sketch__jun10a_8ino.html#a140923a8d9a5f795e6202cdb9ab9de5d',1,'sketch_jun10a.ino']]],
  ['parpadeobloqueo_1',['parpadeoBloqueo',['../sketch__jun10a_8ino.html#a68ffcb0e5b88c240d6abd500c5e21e1b',1,'sketch_jun10a.ino']]]
];
