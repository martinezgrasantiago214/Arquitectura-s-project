var searchData=
[
  ['parpadeoalarma_0',['parpadeoAlarma',['../sketch__jun10a_8ino.html#a140923a8d9a5f795e6202cdb9ab9de5d',1,'sketch_jun10a.ino']]],
  ['parpadeobloqueo_1',['parpadeoBloqueo',['../sketch__jun10a_8ino.html#a68ffcb0e5b88c240d6abd500c5e21e1b',1,'sketch_jun10a.ino']]],
  ['pin_5fbuzzer_2',['PIN_BUZZER',['../sketch__jun10a_8ino.html#a192ea8eaba652d29bfc08675edebb6a2',1,'sketch_jun10a.ino']]],
  ['pin_5fcalefactor_3',['PIN_CALEFACTOR',['../sketch__jun10a_8ino.html#af4c7d204fe9a837fac489d071279121a',1,'sketch_jun10a.ino']]],
  ['pin_5fdht_4',['PIN_DHT',['../sketch__jun10a_8ino.html#ae31e73ed29a89d681154d60c736d8892',1,'sketch_jun10a.ino']]],
  ['pin_5fled_5fazul_5',['PIN_LED_AZUL',['../sketch__jun10a_8ino.html#a83fe533b97afc980d6aa1da6f806edd6',1,'sketch_jun10a.ino']]],
  ['pin_5fled_5frojo_6',['PIN_LED_ROJO',['../sketch__jun10a_8ino.html#abd3af5d6628a1c043c56d3bc2e5cba12',1,'sketch_jun10a.ino']]],
  ['pin_5fled_5fverde_7',['PIN_LED_VERDE',['../sketch__jun10a_8ino.html#a421704e116d709455b8f3340b6c4fb96',1,'sketch_jun10a.ino']]],
  ['pin_5frfid_5frst_8',['PIN_RFID_RST',['../sketch__jun10a_8ino.html#ab4be5758bd0984dd6d300315e574d47f',1,'sketch_jun10a.ino']]],
  ['pin_5frfid_5fss_9',['PIN_RFID_SS',['../sketch__jun10a_8ino.html#a94f682f71b4a56080ed71d61ff11566b',1,'sketch_jun10a.ino']]],
  ['pin_5fsensor_5fluz_10',['PIN_SENSOR_LUZ',['../sketch__jun10a_8ino.html#a9ccfcc021f307b37b065502c3541f275',1,'sketch_jun10a.ino']]],
  ['pin_5fventilador_11',['PIN_VENTILADOR',['../sketch__jun10a_8ino.html#ad8ff202ed1966d6db435a234f7e53204',1,'sketch_jun10a.ino']]],
  ['pinescolumnas_12',['pinesColumnas',['../sketch__jun10a_8ino.html#a6a9763259a69bf5f77d4aa2a1e5fd6fd',1,'sketch_jun10a.ino']]],
  ['pinesfilas_13',['pinesFilas',['../sketch__jun10a_8ino.html#a8cf9c8d26d55e1976ee6cbf99cd02915',1,'sketch_jun10a.ino']]],
  ['principales_14',['Funcionalidades Principales',['../index.html#funcionalidades',1,'']]]
];
