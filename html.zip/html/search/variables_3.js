var searchData=
[
  ['entradaclave_0',['entradaClave',['../sketch__jun10a_8ino.html#aca53b4bff59c1028e4fde6321a7647ca',1,'sketch_jun10a.ino']]],
  ['estadoactual_1',['estadoActual',['../sketch__jun10a_8ino.html#a73cddcc6be8d47d863983dada967e586',1,'sketch_jun10a.ino']]]
];
