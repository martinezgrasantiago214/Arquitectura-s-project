var searchData=
[
  ['general_0',['Descripción General',['../index.html#descripcion',1,'']]]
];
