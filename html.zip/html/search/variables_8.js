var searchData=
[
  ['mostrandoerror_0',['mostrandoError',['../sketch__jun10a_8ino.html#a5be5abfa386a50f2801a99884b7d8d16',1,'sketch_jun10a.ino']]]
];
