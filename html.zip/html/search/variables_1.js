var searchData=
[
  ['clave_5fcorrecta_0',['CLAVE_CORRECTA',['../sketch__jun10a_8ino.html#a79b6b972d76619676588339bf34cb615',1,'sketch_jun10a.ino']]],
  ['columnas_5fteclado_1',['COLUMNAS_TECLADO',['../sketch__jun10a_8ino.html#a74c7fa97a757540c7fb3bae71a45505a',1,'sketch_jun10a.ino']]]
];
