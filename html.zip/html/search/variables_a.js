var searchData=
[
  ['pinescolumnas_0',['pinesColumnas',['../sketch__jun10a_8ino.html#a6a9763259a69bf5f77d4aa2a1e5fd6fd',1,'sketch_jun10a.ino']]],
  ['pinesfilas_1',['pinesFilas',['../sketch__jun10a_8ino.html#a8cf9c8d26d55e1976ee6cbf99cd02915',1,'sketch_jun10a.ino']]]
];
