var searchData=
[
  ['código_0',['Estructura del Código',['../index.html#estructura',1,'']]],
  ['clave_5fcorrecta_1',['CLAVE_CORRECTA',['../sketch__jun10a_8ino.html#a79b6b972d76619676588339bf34cb615',1,'sketch_jun10a.ino']]],
  ['columnas_5fteclado_2',['COLUMNAS_TECLADO',['../sketch__jun10a_8ino.html#a74c7fa97a757540c7fb3bae71a45505a',1,'sketch_jun10a.ino']]],
  ['configurarmaquinaestados_3',['configurarMaquinaEstados',['../sketch__jun10a_8ino.html#ada9f85818dfad1ccef37a80e17315684',1,'sketch_jun10a.ino']]],
  ['confort_20térmico_20y_20control_20de_20acceso_4',['Sistema de Confort Térmico y Control de Acceso',['../index.html',1,'']]],
  ['control_20de_20acceso_5',['Sistema de Confort Térmico y Control de Acceso',['../index.html',1,'']]]
];
