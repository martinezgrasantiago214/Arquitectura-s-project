var searchData=
[
  ['indicepmv_0',['indicePMV',['../sketch__jun10a_8ino.html#abfd066c52a98f76557efd3c416260199',1,'sketch_jun10a.ino']]],
  ['intentosfallidos_1',['intentosFallidos',['../sketch__jun10a_8ino.html#a35c6d852422d51628a060ad8f323746e',1,'sketch_jun10a.ino']]],
  ['intervalo_5fventilador_2',['INTERVALO_VENTILADOR',['../sketch__jun10a_8ino.html#aa9919b787a0d4f978ce581c4041ddaee',1,'sketch_jun10a.ino']]]
];
