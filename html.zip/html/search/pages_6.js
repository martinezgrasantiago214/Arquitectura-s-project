var searchData=
[
  ['hardware_20requerido_0',['Hardware Requerido',['../index.html#hardware',1,'']]]
];
