var searchData=
[
  ['grabardiferentespmventarjetas_0',['grabarDiferentesPMVEnTarjetas',['../sketch__jun10a_8ino.html#a120a1754245a1a6152fa629e492045c0',1,'sketch_jun10a.ino']]],
  ['grabarpmventarjeta_1',['grabarPMVenTarjeta',['../sketch__jun10a_8ino.html#a8bfc472619ba1867d47c99ab6de8d0b9',1,'sketch_jun10a.ino']]]
];
