var searchData=
[
  ['estructura_20del_20código_0',['Estructura del Código',['../index.html#estructura',1,'']]]
];
