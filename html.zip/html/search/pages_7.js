var searchData=
[
  ['principales_0',['Funcionalidades Principales',['../index.html#funcionalidades',1,'']]]
];
