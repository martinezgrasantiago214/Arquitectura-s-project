var searchData=
[
  ['nivelluz_0',['nivelLuz',['../sketch__jun10a_8ino.html#a052cd0746f9963d4571e462de7f5701e',1,'sketch_jun10a.ino']]]
];
