var searchData=
[
  ['tarealcd_0',['tareaLCD',['../sketch__jun10a_8ino.html#a83840f0440befc857adcd0bd7fcee1fa',1,'sketch_jun10a.ino']]],
  ['tarealimpiezaserial_1',['tareaLimpiezaSerial',['../sketch__jun10a_8ino.html#a2be55c137e5f3dbb0ab7fe29dc047057',1,'sketch_jun10a.ino']]],
  ['tarearfid_2',['tareaRFID',['../sketch__jun10a_8ino.html#a3e2e4597cc59b2406fac0b61b152fdf9',1,'sketch_jun10a.ino']]],
  ['tareasensores_3',['tareaSensores',['../sketch__jun10a_8ino.html#aea7874d5d463f4af3c0b63e8ed23a816',1,'sketch_jun10a.ino']]],
  ['tareateclado_4',['tareaTeclado',['../sketch__jun10a_8ino.html#a73b8d85bfaef4beb54e3da1c79894e8d',1,'sketch_jun10a.ino']]],
  ['tareaventilador_5',['tareaVentilador',['../sketch__jun10a_8ino.html#a6f6e9a052b92973364a6b2fd3c5c3c82',1,'sketch_jun10a.ino']]]
];
