var searchData=
[
  ['requerido_0',['Hardware Requerido',['../index.html#hardware',1,'']]]
];
