var searchData=
[
  ['manejarmensajeerror_0',['manejarMensajeError',['../sketch__jun10a_8ino.html#a7d51d80eafa88c52da7ed09c6234a10f',1,'sketch_jun10a.ino']]],
  ['maquinaestados_1',['maquinaEstados',['../sketch__jun10a_8ino.html#af64263505ecd7cecdec1e55f075bde8a',1,'sketch_jun10a.ino']]]
];
