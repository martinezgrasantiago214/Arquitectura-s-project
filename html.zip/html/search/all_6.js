var searchData=
[
  ['hardware_20requerido_0',['Hardware Requerido',['../index.html#hardware',1,'']]],
  ['humedad_1',['humedad',['../sketch__jun10a_8ino.html#a34280c09711b9f4f72211e5c467b57bf',1,'sketch_jun10a.ino']]]
];
